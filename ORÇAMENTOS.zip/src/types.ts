export interface GlassItem {
  id: string;
  description: string;
  width: number; // in mm
  height: number; // in mm
  thickness: string;
  color: string;
  quantity: number;
  pricePerM2: number;
  hardwarePrice: number;
  laborPrice: number;
}

export interface Budget {
  id: string;
  customerName: string;
  customerAddress: string;
  date: string;
  items: GlassItem[];
  discount: number;
  status?: 'pending' | 'approved' | 'rejected';
}

export const GLASS_THICKNESSES = ['4mm', '6mm', '8mm', '10mm', '12mm'];
export const GLASS_COLORS = ['Incolor', 'Verde', 'Fumê', 'Bronze', 'Acidato', 'Refletivo'];
