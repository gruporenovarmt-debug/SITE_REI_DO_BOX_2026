/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useEffect } from 'react';
import { 
  Plus, 
  Trash2, 
  Calculator, 
  FileText, 
  User, 
  MapPin, 
  Phone, 
  Save, 
  Download, 
  ChevronRight,
  Package,
  CheckCircle2,
  Clock,
  XCircle,
  Edit2,
  History,
  RotateCcw
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { GlassItem, Budget, GLASS_THICKNESSES, GLASS_COLORS } from './types';
import { toPng } from 'html-to-image';
import jsPDF from 'jspdf';

export default function App() {
  const [budget, setBudget] = useState<Budget>(() => {
    const saved = localStorage.getItem('currentBudget');
    if (saved) return JSON.parse(saved);
    return {
      id: Math.random().toString(36).substr(2, 9),
      customerName: '',
      customerAddress: '',
      date: new Date().toISOString().split('T')[0],
      items: [],
      discount: 0,
      status: 'pending'
    };
  });

  const [savedBudgets, setSavedBudgets] = useState<Budget[]>(() => {
    const saved = localStorage.getItem('savedBudgets');
    if (saved) return JSON.parse(saved);
    return [];
  });

  const [newItem, setNewItem] = useState<Partial<GlassItem>>({
    description: '',
    width: 0,
    height: 0,
    thickness: '8mm',
    color: 'Incolor',
    quantity: 1,
    pricePerM2: 0,
    hardwarePrice: 0,
    laborPrice: 0
  });

  const [editingId, setEditingId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'budget' | 'history'>('budget');

  useEffect(() => {
    localStorage.setItem('currentBudget', JSON.stringify(budget));
  }, [budget]);

  useEffect(() => {
    localStorage.setItem('savedBudgets', JSON.stringify(savedBudgets));
  }, [savedBudgets]);

  const addItem = () => {
    if (!newItem.description || !newItem.width || !newItem.height) return;
    
    if (editingId) {
      setBudget(prev => ({
        ...prev,
        items: prev.items.map(item => 
          item.id === editingId ? { ...newItem as GlassItem, id: editingId } : item
        )
      }));
      setEditingId(null);
    } else {
      const item: GlassItem = {
        ...newItem as GlassItem,
        id: Math.random().toString(36).substr(2, 9)
      };

      setBudget(prev => ({
        ...prev,
        items: [...prev.items, item]
      }));
    }

    setNewItem({
      description: '',
      width: 0,
      height: 0,
      thickness: '8mm',
      color: 'Incolor',
      quantity: 1,
      pricePerM2: 0,
      hardwarePrice: 0,
      laborPrice: 0
    });
  };

  const editItem = (item: GlassItem) => {
    setNewItem(item);
    setEditingId(item.id);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const removeItem = (id: string) => {
    setBudget(prev => ({
      ...prev,
      items: prev.items.filter(item => item.id !== id)
    }));
  };

  const clearBudget = () => {
    if (confirm('Deseja realmente limpar todo o orçamento?')) {
      setBudget({
        id: Math.random().toString(36).substr(2, 9),
        customerName: '',
        customerAddress: '',
        date: new Date().toISOString().split('T')[0],
        items: [],
        discount: 0,
        status: 'pending'
      });
      setEditingId(null);
    }
  };

  const saveBudget = () => {
    if (!budget.customerName || budget.items.length === 0) {
      alert('Preencha o nome do cliente e adicione pelo menos um item.');
      return;
    }

    const existingIndex = savedBudgets.findIndex(b => b.id === budget.id);
    if (existingIndex >= 0) {
      const updated = [...savedBudgets];
      updated[existingIndex] = budget;
      setSavedBudgets(updated);
    } else {
      setSavedBudgets([budget, ...savedBudgets]);
    }
    alert('Orçamento salvo com sucesso!');
  };

  const loadBudget = (b: Budget) => {
    // Create a deep copy to avoid reference issues and ensure all fields are present
    const budgetCopy = JSON.parse(JSON.stringify(b));
    
    // Sanitize the budget object to ensure all fields are present (backward compatibility)
    const sanitizedBudget: Budget = {
      id: budgetCopy.id || Math.random().toString(36).substr(2, 9),
      customerName: budgetCopy.customerName || '',
      customerAddress: budgetCopy.customerAddress || '',
      date: budgetCopy.date || new Date().toISOString().split('T')[0],
      items: budgetCopy.items || [],
      discount: budgetCopy.discount || 0,
      status: budgetCopy.status || 'pending'
    };
    
    setBudget(sanitizedBudget);
    
    // Reset item form and editing state to a clean state
    setNewItem({
      id: '',
      description: '',
      width: 0,
      height: 0,
      thickness: '8mm',
      color: 'Incolor',
      quantity: 1,
      pricePerM2: 0,
      hardwarePrice: 0,
      laborPrice: 0
    });
    setEditingId(null);
    
    // Switch to budget tab
    setActiveTab('budget');
    
    // Scroll to top for visibility with a slight delay to ensure tab has switched
    setTimeout(() => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }, 150);
  };

  const deleteSavedBudget = (id: string) => {
    if (confirm('Deseja excluir este orçamento salvo?')) {
      setSavedBudgets(prev => prev.filter(b => b.id !== id));
    }
  };

  const calculateItemTotal = (item: GlassItem) => {
    const area = (item.width / 1000) * (item.height / 1000);
    const glassPrice = area * item.pricePerM2;
    return (glassPrice + item.hardwarePrice + item.laborPrice) * item.quantity;
  };

  const totals = useMemo(() => {
    const subtotal = budget.items.reduce((acc, item) => acc + calculateItemTotal(item), 0);
    const total = subtotal - budget.discount;
    return { subtotal, total };
  }, [budget]);

  const handleExportPDF = async () => {
    const element = document.getElementById('budget-print-area');
    if (!element) return;

    try {
      const imgData = await toPng(element, {
        cacheBust: true,
        filter: (node) => {
          const exclusionClasses = ['print:hidden'];
          if (node instanceof HTMLElement) {
            return !exclusionClasses.some(cls => node.classList.contains(cls));
          }
          return true;
        }
      });
      
      const pdf = new jsPDF('p', 'mm', 'a4');
      const imgProps = pdf.getImageProperties(imgData);
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
      
      pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
      pdf.save(`Orcamento_${budget.customerName.replace(/\s+/g, '_')}_${budget.id}.pdf`);
    } catch (error) {
      console.error('Erro ao exportar PDF:', error);
    }
  };

  const handleExportImage = async () => {
    const element = document.getElementById('budget-print-area');
    if (!element) return;

    try {
      const imgData = await toPng(element, {
        cacheBust: true,
        filter: (node) => {
          const exclusionClasses = ['print:hidden'];
          if (node instanceof HTMLElement) {
            return !exclusionClasses.some(cls => node.classList.contains(cls));
          }
          return true;
        }
      });
      
      const link = document.createElement('a');
      
      // Formata a data para DD-MM-AAAA para o nome do arquivo
      const dateParts = budget.date.split('-');
      const formattedDate = dateParts.length === 3 ? `${dateParts[2]}-${dateParts[1]}-${dateParts[0]}` : budget.date;
      
      // Limpa o nome do cliente para evitar caracteres inválidos no arquivo
      const sanitizedName = (budget.customerName || 'Cliente').trim().replace(/[/\\?%*:|"<>]/g, '-');
      
      const fileName = `${sanitizedName}_${formattedDate}_Orcamento.png`;
      link.download = fileName;
      link.href = imgData;
      link.click();
    } catch (error) {
      console.error('Erro ao exportar imagem:', error);
    }
  };

  return (
    <div className="min-h-screen bg-[#F8F9FA] text-[#1A1A1A] font-sans p-4 md:p-8">
      <div id="budget-print-area" className="max-w-5xl mx-auto space-y-8">
        
        {/* Header */}
        <header className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 print:shadow-none print:border-none">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
            <div>
              <h1 className="text-3xl font-bold tracking-tight text-gray-900 flex items-center gap-2">
                <Calculator className="text-blue-600" />
                Vidraçaria Pro - Sistema de Orçamentos
              </h1>
              <p className="text-gray-500 mt-1">Gestão Profissional de Orçamentos</p>
            </div>
            <div className="flex items-center gap-3 print:hidden">
              <button 
                onClick={clearBudget}
                className="flex items-center gap-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 transition-colors rounded-lg font-medium text-red-600"
              >
                <Plus size={18} />
                Novo Orçamento
              </button>
              <button 
                onClick={handleExportPDF}
                className="flex items-center gap-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 transition-colors rounded-lg font-medium"
              >
                <Download size={18} />
                Exportar PDF
              </button>
              <button 
                onClick={handleExportImage}
                className="flex items-center gap-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 transition-colors rounded-lg font-medium"
              >
                <Download size={18} />
                Gerar Imagem
              </button>
              <button 
                onClick={saveBudget}
                className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white transition-colors rounded-lg font-medium shadow-lg shadow-blue-200"
              >
                <Save size={18} />
                Salvar
              </button>
            </div>
          </div>

          {/* Tabs */}
          <div className="flex gap-1 p-1 bg-gray-100 rounded-xl print:hidden">
            <button 
              onClick={() => setActiveTab('budget')}
              className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg font-bold text-sm transition-all ${activeTab === 'budget' ? 'bg-white text-blue-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
            >
              <FileText size={18} />
              Orçamento
            </button>
            <button 
              onClick={() => setActiveTab('history')}
              className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg font-bold text-sm transition-all ${activeTab === 'history' ? 'bg-white text-blue-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
            >
              <History size={18} />
              Histórico
            </button>
          </div>
        </header>

        <AnimatePresence mode="wait">
          {activeTab === 'budget' ? (
            <motion.div 
              key="budget-tab"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="grid grid-cols-1 lg:grid-cols-3 gap-8"
            >
              {/* Left Column: Form */}
              <div className="lg:col-span-2 space-y-8 print:w-full">
                
                {/* Customer Info */}
                <section className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 space-y-4">
                  <h2 className="text-lg font-semibold flex items-center gap-2 border-b pb-3">
                    <User size={20} className="text-blue-600" />
                    Informações do Cliente
                  </h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="md:col-span-2 space-y-1">
                      <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Nome Completo</label>
                      <input 
                        type="text" 
                        value={budget.customerName}
                        onChange={e => setBudget({...budget, customerName: e.target.value})}
                        placeholder="Ex: João Silva"
                        className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                      />
                    </div>
                    <div className="md:col-span-2 space-y-1">
                      <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Endereço da Obra</label>
                      <div className="relative">
                        <MapPin size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                        <input 
                          type="text" 
                          value={budget.customerAddress}
                          onChange={e => setBudget({...budget, customerAddress: e.target.value})}
                          placeholder="Rua, Número, Bairro, Cidade"
                          className="w-full pl-10 pr-4 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                        />
                      </div>
                    </div>
                  </div>
                </section>

                {/* Add Item Form */}
                <section className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 space-y-4 print:hidden">
                  <div className="flex items-center justify-between border-b pb-3">
                    <h2 className="text-lg font-semibold flex items-center gap-2">
                      <Package size={20} className="text-blue-600" />
                      {editingId ? 'Editar Item' : 'Adicionar Item ao Orçamento'}
                    </h2>
                    {editingId && (
                      <button 
                        onClick={() => {
                          setEditingId(null);
                          setNewItem({
                            description: '',
                            width: 0,
                            height: 0,
                            thickness: '8mm',
                            color: 'Incolor',
                            quantity: 1,
                            pricePerM2: 0,
                            hardwarePrice: 0,
                            laborPrice: 0
                          });
                        }}
                        className="text-xs text-red-500 font-bold uppercase hover:underline"
                      >
                        Cancelar Edição
                      </button>
                    )}
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="md:col-span-3 space-y-1">
                      <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Descrição do Item</label>
                      <input 
                        type="text" 
                        value={newItem.description}
                        onChange={e => setNewItem({...newItem, description: e.target.value})}
                        placeholder="Ex: Janela Basculante Banheiro"
                        className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Largura (mm)</label>
                      <input 
                        type="number" 
                        value={newItem.width || ''}
                        onChange={e => setNewItem({...newItem, width: Number(e.target.value)})}
                        placeholder="0"
                        className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Altura (mm)</label>
                      <input 
                        type="number" 
                        value={newItem.height || ''}
                        onChange={e => setNewItem({...newItem, height: Number(e.target.value)})}
                        placeholder="0"
                        className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Quantidade</label>
                      <input 
                        type="number" 
                        value={newItem.quantity || ''}
                        onChange={e => setNewItem({...newItem, quantity: Number(e.target.value)})}
                        placeholder="1"
                        className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Espessura</label>
                      <select 
                        value={newItem.thickness}
                        onChange={e => setNewItem({...newItem, thickness: e.target.value})}
                        className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                      >
                        {GLASS_THICKNESSES.map(t => <option key={t} value={t}>{t}</option>)}
                      </select>
                    </div>
                    <div className="space-y-1">
                      <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Cor do Vidro</label>
                      <select 
                        value={newItem.color}
                        onChange={e => setNewItem({...newItem, color: e.target.value})}
                        className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                      >
                        {GLASS_COLORS.map(c => <option key={c} value={c}>{c}</option>)}
                      </select>
                    </div>
                    <div className="space-y-1">
                      <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Preço m² (R$)</label>
                      <input 
                        type="number" 
                        value={newItem.pricePerM2 || ''}
                        onChange={e => setNewItem({...newItem, pricePerM2: Number(e.target.value)})}
                        placeholder="0.00"
                        className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Ferragens (R$)</label>
                      <input 
                        type="number" 
                        value={newItem.hardwarePrice || ''}
                        onChange={e => setNewItem({...newItem, hardwarePrice: Number(e.target.value)})}
                        placeholder="0.00"
                        className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">Mão de Obra (R$)</label>
                      <input 
                        type="number" 
                        value={newItem.laborPrice || ''}
                        onChange={e => setNewItem({...newItem, laborPrice: Number(e.target.value)})}
                        placeholder="0.00"
                        className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                      />
                    </div>
                    <div className="md:col-span-3 pt-2">
                      <button 
                        onClick={addItem}
                        className={`w-full flex items-center justify-center gap-2 py-3 ${editingId ? 'bg-amber-600 hover:bg-amber-700' : 'bg-blue-600 hover:bg-blue-700'} text-white rounded-xl font-bold transition-all shadow-lg`}
                      >
                        {editingId ? <Edit2 size={20} /> : <Plus size={20} />}
                        {editingId ? 'Atualizar Item' : 'Adicionar ao Orçamento'}
                      </button>
                    </div>
                  </div>
                </section>

                {/* Items List */}
                <section className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
                  <div className="p-6 border-b border-gray-100 flex items-center justify-between">
                    <h2 className="text-lg font-semibold flex items-center gap-2">
                      <FileText size={20} className="text-blue-600" />
                      Itens do Orçamento
                    </h2>
                    <span className="text-sm text-gray-500 font-medium">{budget.items.length} itens</span>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-gray-50 text-gray-400 text-[10px] uppercase tracking-widest font-bold">
                          <th className="px-6 py-4">Descrição</th>
                          <th className="px-6 py-4">Dimensões</th>
                          <th className="px-6 py-4">Especificações</th>
                          <th className="px-6 py-4">Qtd</th>
                          <th className="px-6 py-4 text-right">Total</th>
                          <th className="px-6 py-4 print:hidden"></th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-100">
                        <AnimatePresence mode="popLayout">
                          {budget.items.map((item) => (
                            <motion.tr 
                              key={item.id}
                              initial={{ opacity: 0, y: 10 }}
                              animate={{ opacity: 1, y: 0 }}
                              exit={{ opacity: 0, x: -20 }}
                              className="hover:bg-gray-50/50 transition-colors"
                            >
                              <td className="px-6 py-4">
                                <div className="font-semibold text-gray-900">{item.description}</div>
                                <div className="text-xs text-gray-400">ID: {item.id}</div>
                              </td>
                              <td className="px-6 py-4">
                                <div className="text-sm font-mono">{item.width} x {item.height} mm</div>
                                <div className="text-[10px] text-gray-400">{( (item.width * item.height) / 1000000 ).toFixed(2)} m²</div>
                              </td>
                              <td className="px-6 py-4">
                                <div className="flex gap-1">
                                  <span className="px-2 py-0.5 bg-blue-50 text-blue-600 rounded text-[10px] font-bold uppercase">{item.thickness}</span>
                                  <span className="px-2 py-0.5 bg-gray-100 text-gray-600 rounded text-[10px] font-bold uppercase">{item.color}</span>
                                </div>
                              </td>
                              <td className="px-6 py-4 font-medium text-gray-600">{item.quantity}x</td>
                              <td className="px-6 py-4 text-right font-bold text-gray-900">
                                R$ {calculateItemTotal(item).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                              </td>
                              <td className="px-6 py-4 text-right print:hidden">
                                <div className="flex justify-end gap-1">
                                  <button 
                                    onClick={() => editItem(item)}
                                    className="p-2 text-gray-400 hover:text-blue-500 hover:bg-blue-50 rounded-lg transition-all"
                                  >
                                    <Edit2 size={18} />
                                  </button>
                                  <button 
                                    onClick={() => removeItem(item.id)}
                                    className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all"
                                  >
                                    <Trash2 size={18} />
                                  </button>
                                </div>
                              </td>
                            </motion.tr>
                          ))}
                        </AnimatePresence>
                        {budget.items.length === 0 && (
                          <tr>
                            <td colSpan={6} className="px-6 py-12 text-center text-gray-400 italic">
                              Nenhum item adicionado ainda.
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </section>
              </div>

              {/* Right Column: Summary */}
              <div className="space-y-8">
                
                {/* Status Card */}
                <section className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 space-y-4 print:hidden">
                  <h2 className="text-xs font-bold text-gray-400 uppercase tracking-wider">Status do Orçamento</h2>
                  <div className="flex gap-2">
                    <button 
                      onClick={() => setBudget({...budget, status: 'pending'})}
                      className={`flex-1 flex flex-col items-center gap-2 p-3 rounded-xl border-2 transition-all ${budget.status === 'pending' ? 'border-amber-500 bg-amber-50 text-amber-700' : 'border-gray-100 text-gray-400'}`}
                    >
                      <Clock size={20} />
                      <span className="text-[10px] font-bold uppercase">Pendente</span>
                    </button>
                    <button 
                      onClick={() => setBudget({...budget, status: 'approved'})}
                      className={`flex-1 flex flex-col items-center gap-2 p-3 rounded-xl border-2 transition-all ${budget.status === 'approved' ? 'border-green-500 bg-green-50 text-green-700' : 'border-gray-100 text-gray-400'}`}
                    >
                      <CheckCircle2 size={20} />
                      <span className="text-[10px] font-bold uppercase">Aprovado</span>
                    </button>
                    <button 
                      onClick={() => setBudget({...budget, status: 'rejected'})}
                      className={`flex-1 flex flex-col items-center gap-2 p-3 rounded-xl border-2 transition-all ${budget.status === 'rejected' ? 'border-red-500 bg-red-50 text-red-700' : 'border-gray-100 text-gray-400'}`}
                    >
                      <XCircle size={20} />
                      <span className="text-[10px] font-bold uppercase">Recusado</span>
                    </button>
                  </div>
                </section>

                {/* Totals Card */}
                <section className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 space-y-6 sticky top-8">
                  <h2 className="text-lg font-semibold border-b pb-3">Resumo Financeiro</h2>
                  
                  <div className="space-y-3">
                    <div className="flex justify-between text-gray-500">
                      <span>Subtotal</span>
                      <span className="font-medium">R$ {totals.subtotal.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
                    </div>
                    <div className="space-y-1">
                      <div className="flex justify-between text-gray-500">
                        <span>Desconto</span>
                        <span className="text-red-500 font-medium">- R$ {budget.discount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
                      </div>
                      <input 
                        type="range" 
                        min="0" 
                        max={totals.subtotal} 
                        step="10"
                        value={budget.discount}
                        onChange={e => setBudget({...budget, discount: Number(e.target.value)})}
                        className="w-full h-1.5 bg-gray-100 rounded-lg appearance-none cursor-pointer accent-blue-600 print:hidden"
                      />
                    </div>
                  </div>

                  <div className="pt-6 border-t border-dashed border-gray-200 space-y-4">
                    <div className="flex flex-col">
                      <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">Total à Vista (PIX)</span>
                      <span className="text-4xl font-black text-gray-900 tracking-tighter">
                        R$ {totals.total.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                      </span>
                    </div>
                    
                    <button 
                      onClick={clearBudget}
                      className="w-full flex items-center justify-center gap-2 py-2 text-red-500 hover:bg-red-50 rounded-lg text-xs font-bold uppercase transition-all print:hidden"
                    >
                      <RotateCcw size={14} />
                      Limpar Orçamento
                    </button>
                  </div>

                  <div className="space-y-2 pt-4 print:hidden">
                    <p className="text-[10px] text-gray-400 leading-relaxed">
                      * Este orçamento tem validade de 10 dias.
                      <br />
                      * Prazo de entrega: 15 dias úteis após aprovação.
                    </p>
                  </div>
                </section>

              </div>
            </motion.div>
          ) : (
            <motion.div 
              key="history-tab"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden"
            >
              <div className="p-6 border-b flex items-center justify-between bg-gray-50">
                <h2 className="text-xl font-bold flex items-center gap-2">
                  <History className="text-blue-600" />
                  Orçamentos Salvos
                </h2>
                <span className="text-sm text-gray-500 font-medium">{savedBudgets.length} orçamentos</span>
              </div>

              {/* Financial Summary Box */}
              <div className="p-6 bg-white border-b grid grid-cols-2 md:grid-cols-5 gap-4">
                <div className="space-y-1">
                  <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">1- Total:</p>
                  <p className="text-sm font-bold text-gray-900">
                    R$ {savedBudgets.reduce((acc, b) => acc + b.items.reduce((sum, item) => sum + calculateItemTotal(item), 0) - b.discount, 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                  </p>
                </div>
                <div className="space-y-1">
                  <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">2- Andamento:</p>
                  <p className="text-sm font-bold text-amber-600">
                    R$ {savedBudgets.filter(b => b.status === 'pending').reduce((acc, b) => acc + b.items.reduce((sum, item) => sum + calculateItemTotal(item), 0) - b.discount, 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                  </p>
                </div>
                <div className="space-y-1">
                  <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">3- Fechados:</p>
                  <p className="text-sm font-bold text-green-600">
                    R$ {savedBudgets.filter(b => b.status === 'approved').reduce((acc, b) => acc + b.items.reduce((sum, item) => sum + calculateItemTotal(item), 0) - b.discount, 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                  </p>
                </div>
                <div className="space-y-1">
                  <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">4- Perdidos:</p>
                  <p className="text-sm font-bold text-red-600">
                    R$ {savedBudgets.filter(b => b.status === 'rejected').reduce((acc, b) => acc + b.items.reduce((sum, item) => sum + calculateItemTotal(item), 0) - b.discount, 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                  </p>
                </div>
                <div className="space-y-1">
                  <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">5- Lucro:</p>
                  <p className="text-sm font-bold text-blue-600">
                    R$ {(savedBudgets.filter(b => b.status === 'approved').reduce((acc, b) => acc + b.items.reduce((sum, item) => sum + calculateItemTotal(item), 0) - b.discount, 0) * 0.3).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                  </p>
                </div>
              </div>

              <div className="p-6 space-y-4">
                {savedBudgets.length === 0 ? (
                  <div className="text-center py-12 text-gray-400 italic">
                    Nenhum orçamento salvo ainda.
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {savedBudgets.map(b => (
                      <div key={b.id} className="p-4 border rounded-2xl hover:border-blue-200 hover:bg-blue-50/30 transition-all group">
                        <div className="flex items-center justify-between">
                          <div>
                            <h3 className="font-bold text-gray-900">{b.customerName}</h3>
                            <p className="text-xs text-gray-500">{b.date} • {b.items.length} itens</p>
                            <div className="mt-2">
                              <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                                b.status === 'approved' ? 'bg-green-100 text-green-700' :
                                b.status === 'rejected' ? 'bg-red-100 text-red-700' :
                                'bg-amber-100 text-amber-700'
                              }`}>
                                {b.status === 'approved' ? 'Aprovado' : b.status === 'rejected' ? 'Recusado' : 'Pendente'}
                              </span>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <button 
                              onClick={() => loadBudget(b)}
                              className="p-2 text-blue-600 hover:bg-blue-100 rounded-lg transition-colors"
                              title="Editar Orçamento"
                            >
                              <Edit2 size={18} />
                            </button>
                            <button 
                              onClick={() => deleteSavedBudget(b.id)}
                              className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                              title="Excluir Orçamento"
                            >
                              <Trash2 size={18} />
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Print Only Footer */}
        <footer className="hidden print:block pt-12 border-t border-gray-200 mt-12">
          <div className="grid grid-cols-2 gap-12">
            <div className="space-y-4">
              <div className="h-px bg-gray-300 w-full mt-8"></div>
              <p className="text-center text-xs text-gray-500 font-bold uppercase tracking-widest">Assinatura do Cliente</p>
            </div>
            <div className="space-y-4">
              <div className="h-px bg-gray-300 w-full mt-8"></div>
              <p className="text-center text-xs text-gray-500 font-bold uppercase tracking-widest">Assinatura Vidraçaria Pro</p>
            </div>
          </div>
          <div className="mt-12 text-center text-[10px] text-gray-400">
            Gerado em {new Date().toLocaleString('pt-BR')} | Vidraçaria Pro - Sistema de Orçamentos
          </div>
        </footer>

        {/* History Modal - REMOVED and replaced by Tab */}

      </div>
    </div>
  );
}
